const express = require('express');
const WebSocket = require('ws');
const http = require('http');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

const PORT = 3000;

app.use(express.json({ limit: '20mb' }));
app.use(express.static(path.join(__dirname, '../public')));

// Allow requests from Roblox game (no origin header)
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

let gameState = { parts: [], players: [], terrain: null, timestamp: 0 };
let commandQueue = [];
let browserClients = new Set();

function broadcastTobrowsers(data) {
  const msg = JSON.stringify(data);
  for (const ws of browserClients) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(msg);
    }
  }
}

// ── Lua → Server: push full game state ──────────────────────────────────────
app.post('/gamedata', (req, res) => {
  const data = req.body;
  if (!data || typeof data !== 'object') return res.status(400).json({ error: 'bad data' });

  gameState = data;
  broadcastTobrowsers({ type: 'gamestate', data: gameState });
  res.json({ ok: true });
});

// ── Lua → Server: poll for pending commands ──────────────────────────────────
app.get('/commands', (req, res) => {
  const cmds = commandQueue.splice(0, commandQueue.length);
  res.json({ commands: cmds });
});

// ── Browser → Server: queue a command for Lua ────────────────────────────────
app.post('/command', (req, res) => {
  const cmd = req.body;
  if (!cmd || !cmd.type) return res.status(400).json({ error: 'missing type' });
  commandQueue.push(cmd);
  res.json({ ok: true, queued: commandQueue.length });
});

// ── Browser WebSocket ────────────────────────────────────────────────────────
wss.on('connection', (ws) => {
  browserClients.add(ws);
  console.log(`[WS] Browser connected. Total: ${browserClients.size}`);

  // Send current state immediately on connect
  ws.send(JSON.stringify({ type: 'gamestate', data: gameState }));

  ws.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw.toString());
      if (msg.type === 'command') {
        commandQueue.push(msg.command);
        console.log(`[CMD] Queued: ${JSON.stringify(msg.command)}`);
      }
    } catch (e) {
      console.warn('[WS] Bad message:', e.message);
    }
  });

  ws.on('close', () => {
    browserClients.delete(ws);
    console.log(`[WS] Browser disconnected. Total: ${browserClients.size}`);
  });

  ws.on('error', (e) => console.error('[WS] Error:', e.message));
});

// ── Asset proxy for face textures ────────────────────────────────────────────
const https = require('https');
const assetCache = new Map(); // id → Buffer

app.get('/rbxasset/:id', (req, res) => {
  const id = req.params.id;
  if (!id || !/^\d+$/.test(id)) return res.status(400).send('bad id');

  if (assetCache.has(id)) {
    const buf = assetCache.get(id);
    res.set('Content-Type', 'image/png');
    res.set('Cache-Control', 'public, max-age=86400');
    return res.send(buf);
  }

  // Try roproxy first, then official
  const urls = [
    `https://assetdelivery.roproxy.com/v1/asset/?id=${id}`,
    `https://www.roblox.com/asset/?id=${id}`,
  ];

  function tryFetch(idx) {
    if (idx >= urls.length) return res.status(404).send('not found');
    const url = urls[idx];
    https.get(url, { headers: { 'User-Agent': 'Roblox/WinInet' } }, (resp) => {
      // Follow redirects
      if (resp.statusCode >= 300 && resp.statusCode < 400 && resp.headers.location) {
        let redirectUrl = resp.headers.location;
        // Handle relative redirects
        if (redirectUrl.startsWith('/')) {
          try {
            const parsed = new URL(url);
            redirectUrl = parsed.origin + redirectUrl;
          } catch(e) { return tryFetch(idx + 1); }
        }
        // Skip non-http redirects (error pages etc.)
        if (!redirectUrl.startsWith('http')) return tryFetch(idx + 1);
        https.get(redirectUrl, (resp2) => {
          if (resp2.statusCode !== 200) return tryFetch(idx + 1);
          const chunks = [];
          resp2.on('data', d => chunks.push(d));
          resp2.on('end', () => {
            const buf = Buffer.concat(chunks);
            assetCache.set(id, buf);
            res.set('Content-Type', 'image/png');
            res.set('Cache-Control', 'public, max-age=86400');
            res.send(buf);
          });
        }).on('error', () => tryFetch(idx + 1));
        return;
      }
      if (resp.statusCode !== 200) return tryFetch(idx + 1);
      const chunks = [];
      resp.on('data', d => chunks.push(d));
      resp.on('end', () => {
        const buf = Buffer.concat(chunks);
        // Check if it's XML (Roblox sometimes wraps asset URLs in XML)
        const str = buf.toString('utf8', 0, Math.min(500, buf.length));
        const urlMatch = str.match(/<url>([^<]+)<\/url>/i);
        if (urlMatch) {
          // Fetch the actual URL from XML
          https.get(urlMatch[1], (resp3) => {
            const ch2 = [];
            resp3.on('data', d => ch2.push(d));
            resp3.on('end', () => {
              const imgBuf = Buffer.concat(ch2);
              assetCache.set(id, imgBuf);
              res.set('Content-Type', 'image/png');
              res.set('Cache-Control', 'public, max-age=86400');
              res.send(imgBuf);
            });
          }).on('error', () => tryFetch(idx + 1));
          return;
        }
        assetCache.set(id, buf);
        res.set('Content-Type', 'image/png');
        res.set('Cache-Control', 'public, max-age=86400');
        res.send(buf);
      });
    }).on('error', () => tryFetch(idx + 1));
  }

  tryFetch(0);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n  Roblox Web Engine running at http://localhost:${PORT}`);
  console.log(`  Waiting for Xeno scanner to connect...\n`);
});
