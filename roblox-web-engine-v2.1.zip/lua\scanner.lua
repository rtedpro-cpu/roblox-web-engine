-- ============================================================
--  Roblox Web Engine — Xeno Scanner
--  Run this in Xeno. Keep server running at localhost:3000.
-- ============================================================

local SERVER    = "http://127.0.0.1:3000"
local INTERVAL  = 0.15  -- seconds between updates (~6 fps); adjustable from browser
local MAX_PARTS = 7500  -- adjustable from browser settings

local HttpService = game:GetService("HttpService")
local Players     = game:GetService("Players")
local RunService  = game:GetService("RunService")
local LocalPlayer = Players.LocalPlayer

-- ── HTTP wrapper ──────────────────────────────────────────────────────────────
local httpRequest = http_request or request or (syn and syn.request) or error("No HTTP function found")

local function httpPost(path, body)
    local ok, res = pcall(httpRequest, {
        Url     = SERVER .. path,
        Method  = "POST",
        Headers = { ["Content-Type"] = "application/json" },
        Body    = body,
    })
    return ok, res
end

local function httpGet(path)
    local ok, res = pcall(httpRequest, {
        Url    = SERVER .. path,
        Method = "GET",
    })
    return ok, res
end

-- ── Serialisation helpers ─────────────────────────────────────────────────────
local function vec3(v)   return {v.X, v.Y, v.Z} end
local function color3(c) return {c.R*255, c.G*255, c.B*255} end

local function cframe(cf)
    local r, u, l = cf.RightVector, cf.UpVector, cf.LookVector
    return { cf.X, cf.Y, cf.Z, r.X, r.Y, r.Z, u.X, u.Y, u.Z, l.X, l.Y, l.Z }
end

-- ── Focus target (which player to centre part-sorting around) ─────────────────
-- Set by the browser via "setfocus" command when Follow is clicked.
local focusPlayerName = nil

local function getFocusPos()
    -- Try the focused player first, fall back to local player
    local name = focusPlayerName
    if name then
        local fp = Players:FindFirstChild(name)
        if fp and fp.Character then
            local hrp = fp.Character:FindFirstChild("HumanoidRootPart")
            if hrp then return hrp.Position end
        end
        -- Focused player left / no character — clear focus
        focusPlayerName = nil
    end
    if LocalPlayer and LocalPlayer.Character then
        local hrp = LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
        if hrp then return hrp.Position end
    end
    return nil
end

-- ── Chat collection ───────────────────────────────────────────────────────────
local chatLog       = {}   -- accumulates all messages
local chatSentIdx   = 0    -- last index that was already sent to the server
local MAX_CHAT_LOG  = 200

local function addChat(playerName, message)
    -- Strip rich-text tags Roblox sometimes includes
    local clean = tostring(message):gsub("<[^>]+>", "")
    table.insert(chatLog, { player = playerName, text = clean, time = tick() })
    if #chatLog > MAX_CHAT_LOG then
        table.remove(chatLog, 1)
        chatSentIdx = math.max(0, chatSentIdx - 1)
    end
end

-- Legacy Chatted event (works in most games)
for _, p in ipairs(Players:GetPlayers()) do
    p.Chatted:Connect(function(msg) addChat(p.Name, msg) end)
end
Players.PlayerAdded:Connect(function(p)
    p.Chatted:Connect(function(msg) addChat(p.Name, msg) end)
end)

-- Modern TextChatService (games that use the new chat system)
pcall(function()
    local tcs = game:GetService("TextChatService")
    if tcs then
        tcs.MessageReceived:Connect(function(msg)
            local name = (msg.TextSource and msg.TextSource.Name) or "?"
            addChat(name, msg.Text or "")
        end)
    end
end)

-- ── Workspace scanner ─────────────────────────────────────────────────────────
local function buildCharSet()
    local set = {}
    for _, p in ipairs(Players:GetPlayers()) do
        if p.Character then set[p.Character] = true end
    end
    return set
end

local function inCharacter(inst, charSet)
    local cur = inst.Parent
    while cur and cur ~= workspace do
        if charSet[cur] then return true end
        cur = cur.Parent
    end
    return false
end

local function getShape(inst)
    if inst:IsA("Part") then
        return tostring(inst.Shape):match("%.(%w+)$") or "Block"
    elseif inst:IsA("WedgePart")       then return "Wedge"
    elseif inst:IsA("CornerWedgePart") then return "CornerWedge"
    end
    return "Block"
end

local function getMat(inst)
    return tostring(inst.Material):match("%.(%w+)$") or "SmoothPlastic"
end

local function scanParts()
    local charSet  = buildCharSet()
    local focusPos = getFocusPos()   -- sort centre (local player OR followed player)

    local candidates = {}
    for _, inst in ipairs(workspace:GetDescendants()) do
        if inst:IsA("BasePart") and not inst:IsA("Terrain") and inst.Transparency < 1 then
            if not inCharacter(inst, charSet) then
                local dist = 0
                if focusPos then
                    local d = inst.Position - focusPos
                    dist = d.X*d.X + d.Y*d.Y + d.Z*d.Z
                end
                table.insert(candidates, { inst = inst, dist = dist })
            end
        end
    end

    if focusPos then
        table.sort(candidates, function(a, b) return a.dist < b.dist end)
    end

    local parts = {}
    for i = 1, math.min(#candidates, MAX_PARTS) do
        local inst = candidates[i].inst
        table.insert(parts, {
            name         = inst.Name,
            position     = vec3(inst.Position),
            size         = vec3(inst.Size),
            color        = color3(inst.Color),
            cframe       = cframe(inst.CFrame),
            transparency = inst.Transparency,
            shape        = getShape(inst),
            material     = getMat(inst),
        })
    end
    return parts
end

-- ── Player scanner ────────────────────────────────────────────────────────────
local function scanPlayers()
    local result = {}
    for _, player in ipairs(Players:GetPlayers()) do
        local char = player.Character
        if char then
            local hrp = char:FindFirstChild("HumanoidRootPart")
            local hum = char:FindFirstChildWhichIsA("Humanoid")
            if hrp then
                local bodyParts = {}
                for _, part in ipairs(char:GetDescendants()) do
                    if part:IsA("BasePart") then
                        bodyParts[part.Name] = {
                            position     = vec3(part.Position),
                            size         = vec3(part.Size),
                            color        = color3(part.Color),
                            cframe       = cframe(part.CFrame),
                            transparency = part.Transparency,
                        }
                    end
                end
                table.insert(result, {
                    name        = player.Name,
                    displayName = player.DisplayName,
                    userId      = player.UserId,
                    isLocal     = (player == LocalPlayer),
                    position    = vec3(hrp.Position),
                    health      = hum and hum.Health    or 0,
                    maxHealth   = hum and hum.MaxHealth or 100,
                    parts       = bodyParts,
                })
            end
        end
    end
    return result
end

-- ── Terrain ───────────────────────────────────────────────────────────────────
local function scanTerrain()
    local t = workspace:FindFirstChildWhichIsA("Terrain")
    if not t then return nil end
    local region = t.MaxExtents
    if not region then return { exists = true } end
    return { exists = true, minExtent = vec3(region.Min), maxExtent = vec3(region.Max) }
end

-- ── Command handler ───────────────────────────────────────────────────────────
local function processCommands()
    local ok, res = httpGet("/commands")
    if not ok or not res or res.StatusCode ~= 200 then return end

    pcall(function()
        local data = HttpService:JSONDecode(res.Body)
        for _, cmd in ipairs(data.commands or {}) do
            if cmd.type == "execute" and type(cmd.code) == "string" then
                local fn, err = loadstring(cmd.code)
                if fn then
                    local s, e = pcall(fn)
                    if not s then warn("[WebEngine] exec:", e) end
                else
                    warn("[WebEngine] compile:", err)
                end

            elseif cmd.type == "teleport" then
                local char = LocalPlayer.Character
                local hrp  = char and char:FindFirstChild("HumanoidRootPart")
                if hrp then hrp.CFrame = CFrame.new(cmd.x or 0, cmd.y or 0, cmd.z or 0) end

            elseif cmd.type == "setfocus" then
                focusPlayerName = cmd.name

            elseif cmd.type == "setmaxparts" then
                local v = tonumber(cmd.value)
                if v and v >= 1000 and v <= 20000 then MAX_PARTS = v end

            elseif cmd.type == "setscanrate" then
                local v = tonumber(cmd.value)
                if v and v >= 0.05 and v <= 2 then INTERVAL = v end
            end
        end
    end)
end

-- ── Main loop ─────────────────────────────────────────────────────────────────
local lastTick = 0

RunService.Heartbeat:Connect(function()
    local now = tick()
    if now - lastTick < INTERVAL then return end
    lastTick = now

    -- Only send chat messages that haven't been sent yet
    local newChat = {}
    for i = chatSentIdx + 1, #chatLog do
        table.insert(newChat, chatLog[i])
    end
    chatSentIdx = #chatLog

    local payload = {
        parts     = scanParts(),
        players   = scanPlayers(),
        terrain   = scanTerrain(),
        newChat   = newChat,
        timestamp = now,
    }

    task.spawn(function()
        httpPost("/gamedata", HttpService:JSONEncode(payload))
    end)

    task.spawn(processCommands)
end)

print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
print("  Roblox Web Engine scanner is running!")
print("  Open http://localhost:3000 in a browser")
print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
