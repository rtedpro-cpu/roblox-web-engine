const express = require('express');
const WebSocket = require('ws');
const http = require('http');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

const PORT = 3000;

app.use(express.json({ limit: '20mb' }));
app.use(express.static(path.join(__dirname, '../public')));

// Allow requests from Roblox game (no origin header)
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

let gameState = { parts: [], players: [], terrain: null, timestamp: 0 };
let commandQueue = [];
let browserClients = new Set();

function broadcastTobrowsers(data) {
  const msg = JSON.stringify(data);
  for (const ws of browserClients) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(msg);
    }
  }
}

// ── Lua → Server: push full game state ──────────────────────────────────────
app.post('/gamedata', (req, res) => {
  const data = req.body;
  if (!data || typeof data !== 'object') return res.status(400).json({ error: 'bad data' });

  gameState = data;
  broadcastTobrowsers({ type: 'gamestate', data: gameState });
  res.json({ ok: true });
});

// ── Lua → Server: poll for pending commands ──────────────────────────────────
app.get('/commands', (req, res) => {
  const cmds = commandQueue.splice(0, commandQueue.length);
  res.json({ commands: cmds });
});

// ── Browser → Server: queue a command for Lua ────────────────────────────────
app.post('/command', (req, res) => {
  const cmd = req.body;
  if (!cmd || !cmd.type) return res.status(400).json({ error: 'missing type' });
  commandQueue.push(cmd);
  res.json({ ok: true, queued: commandQueue.length });
});

// ── Browser WebSocket ────────────────────────────────────────────────────────
wss.on('connection', (ws) => {
  browserClients.add(ws);
  console.log(`[WS] Browser connected. Total: ${browserClients.size}`);

  // Send current state immediately on connect
  ws.send(JSON.stringify({ type: 'gamestate', data: gameState }));

  ws.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw.toString());
      if (msg.type === 'command') {
        commandQueue.push(msg.command);
        console.log(`[CMD] Queued: ${JSON.stringify(msg.command)}`);
      }
    } catch (e) {
      console.warn('[WS] Bad message:', e.message);
    }
  });

  ws.on('close', () => {
    browserClients.delete(ws);
    console.log(`[WS] Browser disconnected. Total: ${browserClients.size}`);
  });

  ws.on('error', (e) => console.error('[WS] Error:', e.message));
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n  Roblox Web Engine running at http://localhost:${PORT}`);
  console.log(`  Waiting for Xeno scanner to connect...\n`);
});
